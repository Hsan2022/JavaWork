package sba.sms.services;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import sba.sms.models.Student;
import sba.sms.utils.CommandLine;

import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@FieldDefaults(level = AccessLevel.PRIVATE)
class StudentServiceTest {

    static StudentService studentService;

    @BeforeAll
    static void beforeAll() {
        studentService = new StudentService();
        CommandLine.addData();
    }

    @Test
    void getAllStudents() {
        List<Student> expectedResult = Arrays.asList(
                new Student("reema@gmail.com", "reema brown", "password"),
                new Student("annette@gmail.com", "annette allen", "password"),
                new Student("anthony@gmail.com", "anthony gallegos", "password"),
                new Student("ariadna@gmail.com", "ariadna ramirez", "password"),
                new Student("bolaji@gmail.com", "bolaji saibu", "password"),
                new Student("shirese@gmail.com", "shirese smith", "password")

        );

        List<Student> actualResult = studentService.getAllStudents();

//        Assertions.assertEquals(expectedResult.size(), actualResult.size());

//        Assertions.assertTrue(actualResult.containsAll(expectedResult));

    }

    @Test
    void removeStudent() {
        // Student to remove
        Student studentToRemove = new Student("annette@gmail.com", "annette allen", "password");

        // Remove the student
        boolean result = studentService.removeStudent(studentToRemove);

        // Check if student was successfully removed
        assertThat(result).isTrue();

        // check that the student is no longer in the list
        List<Student> allStudents = studentService.getAllStudents();
        assertThat(allStudents).doesNotContain(studentToRemove);
    }

}
